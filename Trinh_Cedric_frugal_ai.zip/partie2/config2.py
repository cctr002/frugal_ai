# Après la préparation CPU et la création de helper.py.
from helper import *

raw_image_size = 64
image_size = 64
nb_images_per_iter = 4096

load_iter = 0

#Data augmentation
train_transform = A.Compose([
  A.Resize(height=image_size, width=image_size, interpolation=1, p=1.0),
  A.ColorJitter(brightness=(0.85,1.15), contrast=(0.85,1.15),
                saturation=(0.85,1.15), hue=0.05, p=0.8),
  A.ToGray(p=0.02),
  A.HorizontalFlip(p=0.5),
  A.Affine(scale=(0.9,1.1), rotate=(-10,10),
           interpolation=1, p=0.3),
])

val_transform = A.Compose([
    A.Resize(height=image_size, width=image_size, interpolation=1),
])

def data_augm():
  input_data, targets = create_augmented_batch(train_transform)
  cnn.delete_dataset("TRAIN_buf", silent=1)
  cnn.create_dataset("TRAIN_buf", nb_images_per_iter,
                     input_data[:,:], targets[:,:], silent=1)
  return

cnn.init(b_size=32, optimizer=cnn.rms_prop(momentum=0.9), wema=0, dynamic_load=1,
  comp_meth='C_BLAS', mixed_precision="FP16C_FP32A")

data_prep(nb_images_per_iter, raw_image_size, image_size)

input_val, targets_val = create_validation_set(val_transform)
cnn.create_dataset("VALID", 2048, input_val[:,:], targets_val[:,:])
cnn.create_dataset("TEST", 2048, input_val[:,:], targets_val[:,:])

input_data, targets = create_augmented_batch(train_transform)
cnn.create_dataset("TRAIN", nb_images_per_iter, input_data[:,:], targets[:,:])

a_relu = cnn.relu(leaking=0.05, saturation=640000.0)

if(load_iter > 0):
  cnn.input(spatial_shape=[image_size,image_size,1], nb_features=3)
  cnn.load("net_save/net0_s%04d.dat"%load_iter, load_iter, nb_skip_layers=1, bin=1)
else:
  cnn.input(spatial_shape=[image_size,image_size,1], nb_features=3)

  #Block 1
  cnn.conv(f_size=(3,3), nb_filters=16, padding=(1,1), activation=a_relu)
  cnn.conv(f_size=(3,3), nb_filters=16, padding=(1,1), activation=a_relu)
  cnn.pool(p_size=(2,2), p_type="MAX")

  #Block 2
  cnn.conv(f_size=(3,3), nb_filters=32, padding=(1,1), activation=a_relu)
  cnn.conv(f_size=(3,3), nb_filters=32, padding=(1,1), activation=a_relu)
  cnn.pool(p_size=(2,2), p_type="MAX")

  #Block 3
  cnn.conv(f_size=(3,3), nb_filters=64, padding=(1,1), activation=a_relu)
  cnn.pool(p_size=(2,2), p_type="MAX")

  #Classifier
  cnn.dense(nb_neurons=256, activation=a_relu, drop_rate=0.5)
  cnn.dense(nb_neurons=128, activation=a_relu, drop_rate=0.3)
  cnn.dense(nb_neurons=2, strict_size=1, activation="SMAX")


warmup = 10
cycle_length = 500
nb_cycles = 1

l_r_max = 3e-4
l_r_min = 3e-6

nb_iter_per_augm = 1
if(nb_iter_per_augm > 1):
  shuffle_frequency = 1
else:
  shuffle_frequency = 0

for i in range(load_iter, nb_cycles*cycle_length):

  if((i+1) % nb_iter_per_augm == 0):
    t = Thread(target=data_augm)
    t.start()

  if(i < warmup):
    l_r = l_r_min + (l_r_max - l_r_min) * min(i/warmup,1.0)
  else:
    cycle_id = i//cycle_length
    in_cycle_progress = (i%cycle_length)/cycle_length
    l_r = l_r_min + 0.5*(l_r_max*0.8**cycle_id - l_r_min)*(1 + np.cos(np.pi*in_cycle_progress))

  cnn.train(nb_iter=1, learning_rate=l_r, weight_decay=0.01, decoupled_wdecay=1,
    confmat=1, control_interv=50, save_every=100, save_optim_every=100,
    save_bin=1, TC_scale_factor=128.0, shuffle_every=shuffle_frequency)

  if(i == 0):
    cnn.perf_eval()

  if((i+1) % nb_iter_per_augm == 0):
    t.join()
    cnn.swap_data_buffers("TRAIN")

free_data_helper()
