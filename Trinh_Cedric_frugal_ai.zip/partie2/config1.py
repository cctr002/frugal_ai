# Après la préparation CPU et la création de helper.py.
from helper import *

raw_image_size = 64
image_size = 64
nb_images_per_iter = 4096 #Should likely be reduced if the image size is aumgented so examples can fit in RAM

load_iter = 0 #Used to reload a model at a given iteration

#See Albumentation documentation for a list of existing augmentations
train_transform = A.Compose([
  #A.Affine(scale=(...,...), keep_ratio=False, rotate=(...,...), interpolation=1),
  A.Resize(height=image_size, width=image_size, interpolation=1, p=1.0),
  A.ColorJitter(brightness=(0.9,1.1), contrast=(0.9,1.1), saturation=(0.9,1.1), hue=0.05, p=1.0),
  A.ToGray(p=0.02),
  A.HorizontalFlip(p=0.5),
])

val_transform = A.Compose([
    A.Resize(height=image_size, width=image_size, interpolation=1),
])

#This funtion allow to launch data augmentation on a separate thread.
#This way we can train on the GPU and generate new agumented examples in parallel.
def data_augm():
  input_data, targets = create_augmented_batch(train_transform)
  cnn.delete_dataset("TRAIN_buf", silent=1)
  cnn.create_dataset("TRAIN_buf", nb_images_per_iter, input_data[:,:], targets[:,:], silent=1)
  return

cnn.init(b_size=32, optimizer=cnn.rms_prop(momentum=0.9), wema=0, dynamic_load=1,
  comp_meth='C_BLAS', mixed_precision="FP32C_FP32A")

data_prep(nb_images_per_iter, raw_image_size, image_size)

input_val, targets_val = create_validation_set(val_transform)
cnn.create_dataset("VALID", 2048, input_val[:,:], targets_val[:,:])
cnn.create_dataset("TEST", 2048, input_val[:,:], targets_val[:,:])

#Create fist augmentation before parallelization
input_data, targets = create_augmented_batch(train_transform)
cnn.create_dataset("TRAIN", nb_images_per_iter, input_data[:,:], targets[:,:])

a_relu = cnn.relu(leaking=0.05, saturation=640000.0)

if(load_iter > 0):
  cnn.input(spatial_shape=[image_size,image_size,1], nb_features=3)
  cnn.load("net_save/net0_s%04d.dat"%load_iter, load_iter, nb_skip_layers=1, bin=1) #Reset optimizer state
  #cnn.load("optim_save/net_optim0_s%04d.dat"%load_iter, load_iter, bin=1) #Preserve optimizer state
else:
  #Network backbone architecture
  cnn.input(spatial_shape=[image_size,image_size,1], nb_features=3)

  cnn.conv(f_size=(3,3), nb_filters=8 , padding=(1,1), activation=a_relu)
  cnn.pool(p_size=(2,2), p_type="MAX")

  cnn.conv(f_size=(3,3), nb_filters=16, padding=(1,1), activation=a_relu)
  cnn.pool(p_size=(2,2), p_type="MAX")

  cnn.dense(nb_neurons=256, activation=a_relu, drop_rate=0.8)
  cnn.dense(nb_neurons=128, activation=a_relu, drop_rate=0.5)
  cnn.dense(nb_neurons=2 , strict_size=1, activation="SMAX")


warmup = 10
cycle_length = 500
nb_cycles = 1
#Cycle length and/or the number of cycle should be increased with the complexity of the network and task

l_r_max = 4e-4
l_r_min = 4e-6

#In case the creation of new augmented data is too long compared to training, you can
#increase the number of training iteration over a single augmentation
nb_iter_per_augm = 1
if(nb_iter_per_augm > 1):
  shuffle_frequency = 1
else:
  shuffle_frequency = 0


for i in range(load_iter, nb_cycles*cycle_length):

  if((i+1) % nb_iter_per_augm == 0):
    t = Thread(target=data_augm)
    t.start()

  if(i < warmup):
    l_r = l_r_min + (l_r_max - l_r_min) * min(i/warmup,1.0)
  else: # Cyclical cosin learning rate decay with warm restart
    cycle_id = i//cycle_length
    in_cycle_progress = (i%cycle_length)/cycle_length
    l_r = l_r_min + 0.5*(l_r_max*0.8**cycle_id - l_r_min)*(1 + np.cos(np.pi*in_cycle_progress))

  cnn.train(nb_iter=1, learning_rate=l_r, weight_decay=0.01, decoupled_wdecay=1,
    confmat=1, control_interv=50, save_every=100, save_optim_every=100, save_bin=1, TC_scale_factor=128.0, shuffle_every=shuffle_frequency)

  if(i == 0):
    cnn.perf_eval()

  if((i+1) % nb_iter_per_augm == 0):
    t.join()
    cnn.swap_data_buffers("TRAIN")

free_data_helper()
