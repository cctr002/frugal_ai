# Cellule à exécuter après la préparation des données dans config6_T4.ipynb.
import torch

raw_image_size = 128
image_size = 96
eval_batch = 128
precision = "FP16C_FP32A"
checkpoint = "/content/config4_t4_96.dat"
val_transform = A.Compose([A.Resize(image_size, image_size, interpolation=1)])

def config4():
  relu = cnn.relu(leaking=0.05, saturation=64.0)
  cnn.input(spatial_shape=[image_size, image_size, 1], nb_features=3)
  cnn.conv(f_size=(4,4), stride=(2,2), padding=(1,1), nb_filters=24, activation=relu)
  for width in (48, 96):
    cnn.pool(p_size=(2,2), p_type="MAX")
    for _ in range(2):
      cnn.conv(f_size=(3,3), padding=(1,1), nb_filters=width, activation=relu)
  cnn.pool(p_size=(2,2), p_type="MAX")
  cnn.conv(f_size=(3,3), padding=(1,1), nb_filters=128, activation=relu)
  cnn.conv(f_size=(1,1), nb_filters=2, activation="LIN")
  cnn.pool(p_size=(1,1), p_global=1, p_type="AVG", activation="SMAX")

def check_budget():
  cnn.init(b_size=eval_batch, inference_only=1, dynamic_load=1,
           comp_meth="C_CUDA", mixed_precision=precision)
  try:
    config4()
    data_prep(0, raw_image_size, image_size, test_mode=1)
    x, y = create_validation_set(val_transform)
    cnn.create_dataset("TEST", len(y), x, y)
    cnn.forward(drop_mode="AVG_MODEL", no_error=1, saving=0, return_output=0)
    torch.cuda.synchronize()
    times = []
    for _ in range(5):
      start = time.perf_counter()
      cnn.forward(drop_mode="AVG_MODEL", no_error=1, saving=0, return_output=0)
      torch.cuda.synchronize()
      times.append(1000 * (time.perf_counter() - start))
    median = float(np.median(times))
    print(f"Batch {eval_batch}, 2 048 images : {np.round(times, 1)} ms ; médiane {median:.1f} ms")
    return median
  finally:
    free_data_helper()

latency_ms = check_budget()

if latency_ms >= 300:
  raise RuntimeError("Budget dépassé. Ajuster eval_batch et relancer la cellule de chronométrage.")
nb_images_per_iter = 2048
load_iter = 0
train_transform = A.Compose([
  A.Resize(image_size, image_size, interpolation=1),
  A.ColorJitter(brightness=(0.85,1.15), contrast=(0.85,1.15), saturation=(0.85,1.15), hue=0.05, p=0.8),
  A.ToGray(p=0.02), A.HorizontalFlip(p=0.5),
  A.Affine(scale=(0.9,1.1), rotate=(-10,10), interpolation=1, p=0.3),
])

#This funtion allow to launch data augmentation on a separate thread.
#This way we can train on the GPU and generate new agumented examples in parallel.
def data_augm():
  input_data, targets = create_augmented_batch(train_transform)
  cnn.delete_dataset("TRAIN_buf", silent=1)
  cnn.create_dataset("TRAIN_buf", nb_images_per_iter, input_data[:,:], targets[:,:], silent=1)
  return

cnn.init(b_size=32, optimizer=cnn.rms_prop(momentum=0.9), wema=0, dynamic_load=1,
  comp_meth='C_CUDA', mixed_precision=precision)
config4()

data_prep(nb_images_per_iter, raw_image_size, image_size)

input_val, targets_val = create_validation_set(val_transform)
cnn.create_dataset("VALID", 2048, input_val[:,:], targets_val[:,:])


#Create fist augmentation before parallelization
input_data, targets = create_augmented_batch(train_transform)
cnn.create_dataset("TRAIN", nb_images_per_iter, input_data[:,:], targets[:,:])

warmup = 10
cycle_length = 500
nb_cycles = 1
#Cycle length and/or the number of cycle should be increased with the complexity of the network and task

l_r_max = 3e-4
l_r_min = 3e-6

#In case the creation of new augmented data is too long compared to training, you can
#increase the number of training iteration over a single augmentation
nb_iter_per_augm = 1
if(nb_iter_per_augm > 1):
  shuffle_frequency = 1
else:
  shuffle_frequency = 0


for i in range(load_iter, nb_cycles*cycle_length):

  if((i+1) % nb_iter_per_augm == 0):
    t = Thread(target=data_augm)
    t.start()

  if(i < warmup):
    l_r = l_r_min + (l_r_max - l_r_min) * min(i/warmup,1.0)
  else: # Cyclical cosin learning rate decay with warm restart
    cycle_id = i//cycle_length
    in_cycle_progress = (i%cycle_length)/cycle_length
    l_r = l_r_min + 0.5*(l_r_max*0.8**cycle_id - l_r_min)*(1 + np.cos(np.pi*in_cycle_progress))

  cnn.train(nb_iter=1, learning_rate=l_r, weight_decay=0.01, decoupled_wdecay=1,
    confmat=1, control_interv=50, save_every=100, save_optim_every=100, save_bin=1, TC_scale_factor=128.0, shuffle_every=shuffle_frequency)

  if(i == 0):
    cnn.perf_eval()

  if((i+1) % nb_iter_per_augm == 0):
    t.join()
    cnn.swap_data_buffers("TRAIN")

cnn.save(checkpoint, bin=1)
free_data_helper()
